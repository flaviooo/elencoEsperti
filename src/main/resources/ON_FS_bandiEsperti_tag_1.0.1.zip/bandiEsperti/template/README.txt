In questa cartella ci sono i template dei report usati in questa applicazione.
I file .jrxml sono i sorgenti mentre i .jasper sono i compilati.

I file .jrxml (ovvero i sorgenti) sono stati realizzati con iReport 3.7.0